# PeerJS API Reference

We've moved! <a href="http://peerjs.com/docs#api">Check out our new API
reference.</a>
