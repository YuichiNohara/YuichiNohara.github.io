## PeerJS Documentation

We've moved! <a href="http://nttcom.github.io/skyway/docs">Check out our new
documentation.</a>

## PeerJS links

###[Browser compatibility and limitations](http://peerjs.com/status)

### [Discuss PeerJS on our Google Group](https://groups.google.com/forum/?fromgroups#!forum/peerjs)
